Additional Topics :

	JPA , Hibernate , EJB - Using their own Query language 
	EJB Services can be exposed as web services as well
	we have to write a specific exception handling
	Annotations, JNDI Binding, Call backs , Timer services
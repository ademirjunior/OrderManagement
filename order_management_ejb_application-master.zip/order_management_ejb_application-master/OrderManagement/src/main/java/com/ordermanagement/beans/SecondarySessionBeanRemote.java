package com.ordermanagement.beans;

import javax.ejb.Remote;

@Remote
public interface SecondarySessionBeanRemote {
	void secondarySessionMethod();

}
